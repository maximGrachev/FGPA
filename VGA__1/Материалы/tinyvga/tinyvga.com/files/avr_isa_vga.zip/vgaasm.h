#ifndef VGAASM_H
#define VGAASM_H

// Prototypes
void    VgaMemoryWriteB(register DBLWORD addr,register BYTE val); 

BYTE    VgaMemoryReadB(register DBLWORD addr); 

void    VgaMemoryWriteW(register DBLWORD addr,register WORD val); 

WORD    VgaMemoryReadW(register DBLWORD addr); 

void    VgaIoWriteIx(register WORD addr,register WORD ValIx);

BYTE    VgaIoReadIx(register WORD addr,register BYTE Ix);

#endif
