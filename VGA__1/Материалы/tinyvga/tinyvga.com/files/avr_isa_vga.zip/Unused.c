#else
   #if defined TVGA9000

   code  BYTE  INIT_GRC_EXTEND[]=         // Begin 0x09
   {0x00,0x01,0x3A,0x80,0x0B,0x0E,0x00};

   code  BYTE  INIT_CRTC_EXTEND[]=        // Begin 0x19
   {0x00,0x00,0x00,0x00,0x00,0x00,0x81,
    0x00,0x00,0xD8,0x00,0x00,0xFF,0x20,
    0x00,0x50};

//   code  BYTE  INIT_SEQ_EXTEND[]=         // Begin 0x05
//   {0x00,0x00,0x24,0x00,0x00,0x00,0x43,
//    0x8C,0x00,0x40,0x7F,0x03,0x00,0x03,
//    0x00,0x02,0x00,0x00,0x00,0x00,0x00,
//    0x00,0x43,0x8C,0x00,0x40,0x7F};

   #endif






void ModeTest()
{
//   data BYTE i;

//   for(i=0;i <0x20;i++)
//   {
//      Clear0DH(i);
//   }

}



BYTE  getch(void)
{
   data BYTE  v;
   SetColor(0x0E);
   printf("Silabs Vga driver started!\r\n");
   SetColor(0x0F);
   printf("Produced by Zoltan Bali.\r\n");
   printf("******************************\r\n");
   printf("Current mode 03H\r\n");
   printf("Horizontal 80 char\r\n");
   printf("Vertical 25 rows\r\n");
   printf("Horizontal frequency: 31.55 kHz\r\n");
   printf("Vertikal   frequency: 70.29  Hz\r\n");
   printf("Color number: 16\r\n");
   printf("To be continued.");
   printf("Bye !");

   VgaPortOut(CRTC_ADDR,0x22);
   v = VgaPortIn(CRTC_ADDR+1);
   printf("%x\r\n",(WORD)v);


   TextClear(0x0F);
   v = 0;
   do
   {
      SetColor(v);
      putchar('8');
      v++;
   }while(v);

   return(1);
}




  code BYTE   INIT_PEL_EXTEND[]=
   {
      0x00,0x0F,0x08,0x04,0x00,0x0F,0x08,0x00,
      0x00,0x0F,0x08,0x07,0x00,0x07,0x07,0x07,
      0x07,0x07,0x07,0x07,0x07,0x07,0x00,0x07,
      0x07,0x07,0x07,0x04,0x00,0x0F,0x08,0x00,
      0x00,0x0F,0x04,0x00,0x0F,0x08,0x00,0x00,
      0x0F,0x08,
   };



   i=0x15;
   do
   {
      switch(i)
      {
         case 0x20:
            col1 = 0x07;col2 = 0x00;col3 = 0x00;col4 = 0x07;
            break;
         case 0x21:
            col1 = 0x00;col2 = 0x07;col3 = 0x07;col4 = 0x07;
            break;
         case 0x24:
            col1 = 0x07;col2 = 0x00;col3 = 0x07;col4 = 0x07;
            break;
         case 0x26:
            col1 = 0x07;col2 = 0x01;col3 = 0x07;col4 = 0x07;
            break;
         case 0x27:
            col1 = 0x07;col2 = 0x07;col3 = 0x00;col4 = 0x07;
            break;
         case 0x29:
            col1 = 0x07;col2 = 0x07;col3 = 0x07;col4 = 0x00;
            break;
         case 0x2B:
            col1 = 0x00;col2 = 0x07;col3 = 0x00;col4 = 0x07;
            break;
         case 0x2C:
            col1 = 0x07;col2 = 0x07;col3 = 0x07;col4 = 0x00;
            break;
         case 0x2D:
            col1 = 0x07;col2 = 0x00;col3 = 0x07;col4 = 0x07;
            break;
         default:
            col1 = 0xff;
            col2 = col1;
            col3 = col1;
            col4 = col1;
            break;
      }
     VgaPortIn(ATTRCON_ADDR);
     VgaPortIn(ATTRCON_ADDR+1);

//      VgaPortIn(0x03DA);
     VgaPortIn(ATTRCON_ADDR);
     VgaPortIn(ATTRCON_ADDR+1);
      VgaPortOut(ATTRCON_ADDR,i);
      VgaPortOut(ATTRCON_ADDR,col1);


//      VgaPortIn(0x03DA);
     VgaPortIn(ATTRCON_ADDR);
     VgaPortIn(ATTRCON_ADDR+1);
      VgaPortOut(ATTRCON_ADDR,i+64);
      VgaPortOut(ATTRCON_ADDR,col2);

//      VgaPortIn(0x03DA);
     VgaPortIn(ATTRCON_ADDR);
     VgaPortIn(ATTRCON_ADDR+1);
      VgaPortOut(ATTRCON_ADDR,i+128);
      VgaPortOut(ATTRCON_ADDR,col3);

//      VgaPortIn(0x03DA);
      VgaPortOut(ATTRCON_ADDR,i+192);
      VgaPortOut(ATTRCON_ADDR,col4);
      i++;
   }while(i<0x40);


    for(j=0;j<21;j++)
   {
     VgaPortIn(ATTRCON_ADDR);
     VgaPortIn(ATTRCON_ADDR+1);
     VgaPortOut(ATTRCON_ADDR,i);
     VgaPortOut(ATTRCON_ADDR,*dataptr);
 //    wr = VgaPortIn(ATTRCON_ADDR);
//     rr = VgaPortIn(ATTRCON_ADDR+1);
     dataptr++;
   }
   VgaPortOut(ATTRCON_ADDR,0x20);



      for(i=0x15;i<256;i++)
      {
         j=0;
         do
         {
//            VgaPortIn(ATTRCON_ADDR);
//            VgaPortIn(ATTRCON_ADDR+1);
            VgaPortIn(0x3DA);
            VgaPortOut(ATTRCON_ADDR,i);
            VgaPortOut(ATTRCON_ADDR,j);
            j++;
         }while(j);
      }
      VgaPortOut(ATTRCON_ADDR,0x20);
      SetVideoMode(MODE00H);



main
   VgaPortOut(MISC_ADDR,0x67);
   VgaPortOut(0x03D4,0x1A);
   VgaPortOut(0x03D5,0x10);   //Clear write protection

  // VgaSearchMemWR();

  // VgaRegTest();




   VgaPortOut(0x03D4,0x1A);
   VgaPortOut(0x03D5,0x50);   //Clear write protection

   VgaPortOut(0x03CE,0x0b);
   VgaPortOut(0x03CF,0x02);   // Set clock divider

 //  SearchUnlockBit();



   VgaInitExtend();
//   VgaRegTest();

 //  VgaRegTest();

   VgaPortOut(0x03D4,0x1A);
   VgaPortOut(0x03D5,0x10);   //Clear write protection

   VgaPortOut(0x03CE,0x0b);
   VgaPortOut(0x03CF,0x02);   // Set clock divider

   VgaInitExtend();

   setpalette16();

   VgaPortInit(mode0Dh);
   ReadBIOSfont(Font8x8,8);
   for(i=0;i<4096;i++)
   {
      VgaMemoryWrite(0x00A00000+i,0x64);
   }
   for(i=0;i<4096;i++)
   {
     v = VgaMemoryRead(0xA00000+i);
     XBR0 = 0;
   }

   VgaSearchMemory();

   while(1);

//******
   sh = 1;
   for(j=0;j<255;j++)
   {
      VgaPortOut(0x03CE,0x15);
      VgaPortOut(0x03CF,j);   //Test value
      v = VgaPortIn(0x03CF);
      sh = sh<<1;
      for(i=0;i<8000;i++);
   }
   while(1);

}



typedef int intfunc(int);
typedef intfunc    *fad;

typedef struct  _MENUITEM
{
  char  *text;
  char   key;
  int   helpindex;
  fad   function;
  int   param;
} MENUITEM;

typedef struct  _MENUTYPE
{
  char      *header;
  BYTE      x;
  BYTE      y;
  BYTE      xs;
  BYTE      ys;
  BYTE      itemno;
  MENUITEM  *items;
  BYTE      hierarch;
  BYTE      lastitem;
} MENUTYPE;

static  char  exittxt[] = "eXit";

extern intfunc  data, r_data, w_data, statf,
                regr, linf, barf,
                save, load;

intfunc menu;
intfunc dir,shell;

MENUITEM  items_0[] =
{// Text        Key   Hlp    func    param
  "Directory",  'D',  1,     dir,     0,
  "Os shell",   'G',  2,     shell,   0,
  "File",       'F',  3,     menu,    3,
  exittxt,      'X',  -1,    NULL,    0
};
#define N0  sizeof(items_0)/sizeof(MENUITEM)

MENUITEM  items_1[] =
{// Text        Key   Hlp    func    param
  "Default",    'D',  4,     data,    7,
  "Read data",  'R',  5,     r_data,  1,
  "ListData",   'L',  6,     w_data,  2,
  "Statistics", 'S',  7,     statf,   3,
  exittxt,      'X',  -1,    NULL,    0
};
#define N1  sizeof(items_1)/sizeof(MENUITEM)

MENUITEM  items_2[] =
{// Text        Key   Hlp    func    param
  "Regression", 'R',  8,     regr,    4,
  "Plot",       'P',  9,     linf,    5,
  "Bar",        'B',  10,    barf,    6,
  exittxt,      'X',  -1,    NULL,    0
};
#define N2  sizeof(items_2)/sizeof(MENUITEM)

MENUITEM  items_3[] =
{// Text        Key   Hlp    func    param
  "Save",       'S',  11,    save,    0,
  "Load",       'L',  12,    load,    0,
  exittxt,      'X',  -1,    NULL,     0
};
#define N3  sizeof(items_3)/sizeof(MENUITEM)

MENUTYPE  menus[] =
{// head    x   y   xs    ys    Itemno   items    hiera    last
  "",       9,  2,  13,   N0+3,   N0,   items_0,    1,      0,
  "",      35,  2,  14,   N1+3,   N1,   items_1,    1,      0,
  "",      61,  2,  14,   N2+3,   N2,   items_2,    1,      0,
  "fILES", 11,  6,   8,   N3+3,   N3,   items_3,    0,      1
}



//*********************************************************************

void  VgaMemoryWriteOld(register DBLWORD addr,register BYTE val)
{

   ADDRESS_HIGH = (addr>>16)&0xF0 ;    // AddressHigh
   DDRA = 0xFF;                        // ADDRESS_LOW is output
   ADDRESS_LOW  = addr&0xFF;           // Place the A0..A7 bit to BUS low
   ADDRESS_LATCH_ENABLE = 1;           // Latch the value
   ADDRESS_MID = (addr>>8)&0xFF;       // Place the A8..A15 bit to BUS mid
   ADDRESS_LATCH_ENABLE = 0;
   ADDRESS_LOW = val;                  // Place the data to BUS low
   MEMORY_WRITE = 0;                   // Write to addressed io port
   ADMUX=0;
   while(!IO_CH_READY);
   ADDRESS_LOW = val;                  // Place the data to BUS low
   MEMORY_WRITE = 1;
   DDRA = 0x00;                        // ADDRESS_LOW is input

}

//*********************************************************************

BYTE  VgaMemoryReadOld(register DBLWORD addr)
{
   BYTE val;


   ADDRESS_HIGH = (addr>>16)&0xF0 ;    // AddressHigh
   DDRA = 0xFF;                        // ADDRESS_LOW is output
   ADDRESS_LOW  = addr&0xFF;           // Place the A0..A7 bit to BUS low
   ADDRESS_LATCH_ENABLE = 1;           // Latch the value
   ADDRESS_MID = (addr>>8)&0xFF;       // Place the A8..A15 bit to BUS mid
   ADDRESS_LATCH_ENABLE = 0;
   DDRA = 0x00;                        // ADDRESS_LOW is input mode
   ADDRESS_LOW = 0xFF;                 // Set the open drain outputs high
   MEMORY_READ = 0;                    // Write to addressed io port
   while(!IO_CH_READY);
   val = ADDRESS_LOW ;                 // Place the data to BUS low
   MEMORY_READ = 1;
   DDRA = 0x00;                        // ADDRESS_LOW is input
   return(val);

}



__flash BYTE mode10Ah[62] = {
// MISC reg,  STATUS reg,    SEQ regs
   0x67,      0x00,          0x03,0x00,0x03,0x00,0x02,

// CRTC regs

// Kh = 132/80 = 1.65
// Kv = 43/25 =  1.72

// HorizontalTotal    = 95  -> 132 +(15*1.65) = 24.75+132 = 156,75  0x9D
// HorizontalDisplay  = 79  -> 131  0x83
// StartHblank        = 80  -> 132  0x84
// EndHblank          = 130 -> 132 +(50*1.65) = 132+ 82.5 = 214.5  0xD6
// StartHretrace      = 85  -> 132 +(5*1.65) =  132+8.25  = 140.25 0x8C
// EndHretrace        = 129 -> 214.5-1 = 213.5                     0xD5

// Vtotal             = 447 -> 687+(47*1.72)  = 80.84+687 = 767.84 0x2FF
// StartVretrace      = 412 -> 687+(12*1.72)  = 20.64+687 = 707.64 0x2C3
// EndVretrace        =  14 -> 6
// VdisplEnd          = 399 ->  (43*16)-1 = 687                    0x2AF
// LogicalWidth       =  40   (40*2byte=80)  -> 132/2 = 66         0x42
// StartVblank        = 406 0x96 -> 687+(6*1.72) = 10.32+687 = 697.32  0x2B9
// EndVblank          = 191 0xB9 -> 245                                0x5C
//    1    2    3    4    5    6    7    8    9    A    B    C    D    E    F

0x5F,0x4F,0x50,0x82,0x55,0x81,0xBF,0x1F,0x00,0x4F,0x0E,0x0F,0x00,0x00,0x00,0x01,
0x9C,0x8E,0x8F,0x28,0x1F,0x96,0xB9,0xA3,0xFF,

0x9D,0x83,0x84,0xD6,0x8C,0xD5,0xFF,0xF0,0x00,0x6F,0x0E,0x0F,0x00,0x00,0x00,0x01,
0xC3,0x86,0xAF,0x42,0x1F,0xB9,0x5C,0xA3,0xFF,
// GRAPHICS regs
0x00,0x00,0x00,0x00,0x00,0x10,0x0E,0x00,0xFF,
// ATTRIBUTE CONTROLLER regs
0x00,0x01,0x02,0x03,0x04,0x05,0x14,0x07,0x38,0x39,0x3A,0x3B,0x3C,0x3D,0x3E,0x3F,
0x04,0x00,0x0F,0x08,0x00
};
//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=


   else if (mode == MODE10AH)                   // 132 x 43 x 16
   {
      ModeSet(mode10Ah);
      setpalette16();
      FontsRead(Font1,16);

      Mode.width = 132;
      Mode.height = 43;
      Mode.width_bytes = 5676;
      Mode.colors = 16;
      Mode.attrib = TVU_TEXT;
      VgaIoWriteIx(0x3CE,0x380B);
      do
      {
       i = Remote();

      }while(i!='1');
   }



 #include  <math.h>
#include  <stdlib.h>
#include  "types.h"

#define Pi        3.1415926535897932385
#define Deg       Pi/180
#define RadToDeg  180/Pi
#define DegToRad  1/RadToDeg


extern void pixel(WORD x, WORD y, BYTE color);



  BYTE fillvalue;
  BYTE oldvalue;


void Line(WORD x1, WORD y1, WORD x2, WORD y2, BYTE color)
{
  int i,DeltaX,DeltaY,NumPixels;
  int d,dInc1,dInc2;
  int x,xInc1,xInc2;
  int y,yInc1,yInc2;

  DeltaX = x2 - x1;
  DeltaY = y2 - y1;

  DeltaY = abs(DeltaY);
  DeltaX = abs(DeltaX);

  if (DeltaX >= DeltaY)
  {
    NumPixels = DeltaX + 1;
    d = (DeltaY << 2) - DeltaX;
    dInc1 = DeltaY << 1;
    dInc2 = (DeltaY - DeltaX)<< 1;
    xInc1 = 1;
    xInc2 = 1;
    yInc1 = 0;
    yInc2 = 1;
  }
  else
  {
    NumPixels = DeltaY + 1;
    d = (DeltaX << 2) - DeltaY;
    dInc1 = DeltaX << 1;
    dInc2 = (DeltaX - DeltaY) << 1;
    xInc1 = 0;
    xInc2 = 1;
    yInc1 = 1;
    yInc2 = 1;
  }
  if (x1 > x2)
  {
    xInc1 = - xInc1;
    xInc2 = - xInc2;
  }
  if (y1 > y2)
  {
    yInc1 = - yInc1;
    yInc2 = - yInc2;
  }
  x = x1;
  y = y1;

  for(i=1; i<NumPixels+1;i++)
  {
    pixel(x, y, color);
    if(d < 0)
    {
      d = d + dInc1;
      x = x + xInc1;
      y = y + yInc1;
    }
    else
    {
      d = d + dInc2;
      x = x + xInc2;
      y = y + yInc2;
    }
  }
}

void Hline(WORD x,WORD y,WORD len,BYTE col)
{
  do
  {
    pixel(x,y+len-1,col);
  }while(--len);

}
void  Circle(WORD CoordX, WORD CoordY, WORD Radius,BYTE color)
{
  WORD X,Y;
  double Alpha,temp,cosalfa;

  X = Radius; Y = 0;
  do
  {
    do
    {
      pixel(CoordX+X,CoordY+Y,color);
      pixel(CoordX-X,CoordY+Y,color);
      pixel(CoordX-X,CoordY-Y,color);
      pixel(CoordX+X,CoordY-Y,color);
      pixel(CoordX+Y,CoordY-X,color);
      pixel(CoordX-Y,CoordY-X,color);
      pixel(CoordX-Y,CoordY+X,color);
      pixel(CoordX+Y,CoordY+X,color);
      Y = Y+1;
      Alpha = atan((double)Y/(double)X);
      cosalfa = cos(Alpha)*Radius;
      cosalfa = __round(cosalfa);
      temp = __round((cos(Alpha)*Radius));
    }while(!( temp < X));
    X =X-1;
  }while(!((X<=0) || (X<Y)));
}

void  FillCircle(WORD CoordX, WORD CoordY, WORD Radius, BYTE fcolor)
//{ Dcolor = Draw color Circle. Fcolor = Fill color inner circle }
{
  WORD X,Y,Lenght,Lenghs;

  X=Radius;Y=0;
  do
  {
    do
    {
      Lenght= (2*X);
      Lenghs= (CoordX+Y)-(CoordX-Y);
      Hline(CoordX-X,CoordY+Y,Lenght,fcolor);
      Hline(CoordX-X,CoordY-Y,Lenght,fcolor);
      Hline(CoordX-Y,CoordY-X,Lenghs,fcolor);
      Hline(CoordX-Y,CoordY+X,Lenghs,fcolor);
      Y=Y+1;
    }while(!(__round((cos(atan(Y/X))*Radius)) < X));
    X=X-1;
  }while(!((X<=0) || (X<Y)));
}

void  Arc(WORD x_center, WORD y_center, WORD radius, WORD s_angle, WORD e_angle, BYTE CurrentColor)
//{ An algorithm to draw an arc. Crude but it works (anyone have a better one?) }
{
  int p;
  WORD x, y;
  double Alpha;

  if(radius==0)
  {
    pixel(x_center,y_center,CurrentColor); return;
  }
  s_angle = s_angle%361;
  e_angle = e_angle%361;
  if(s_angle > e_angle)
  {
    s_angle = s_angle^e_angle; e_angle = e_angle^s_angle; s_angle = e_angle^s_angle;
  }
  x = 0;
  y = radius;
  p = 3-2*radius;
  while(x <= y)
  {
    Alpha = RadToDeg*atan((double)x/y);
    if((Alpha>=s_angle) && (Alpha<=e_angle)) pixel(x_center+x, y_center-y, CurrentColor);
    if((90-Alpha>=s_angle) && (90-Alpha<=e_angle))   pixel(x_center+y, y_center-x, CurrentColor);
    if((90+Alpha>=s_angle) && (90+Alpha<=e_angle))   pixel(x_center+y, y_center+x, CurrentColor);
    if((180-Alpha>=s_angle) && (180-Alpha<=e_angle)) pixel(x_center+x, y_center+y, CurrentColor);
    if((180+Alpha>=s_angle) && (180+Alpha<=e_angle)) pixel(x_center-x, y_center+y, CurrentColor);
    if((270-Alpha>=s_angle) && (270-Alpha<=e_angle)) pixel(x_center-y, y_center+x, CurrentColor);
    if((270+Alpha>=s_angle) && (270+Alpha<=e_angle)) pixel(x_center-y, y_center-x, CurrentColor);
    if((360-Alpha>=s_angle) && (360-Alpha<=e_angle)) pixel(x_center-x, y_center-y, CurrentColor);
    if( p<0 )
    {
      p = p+4*x+6;
    }
    else
    {
      p = p+4*(x-y)+10;
      y--;
    }
    x++;
  }
}

void Arc1(WORD CoordX, WORD CoordY, WORD Radius, WORD s_angle,WORD e_angle, BYTE Color)
{
  WORD X,Y;
  WORD Alpha;

  X=Radius;Y=0;
  do
  {
    do
    {
      Alpha = __round(atan((double)Y/X)/Deg);
      if((Alpha>=s_angle) && (Alpha<=e_angle)) pixel(CoordX+Y,CoordY-X,Color);
      if((90-Alpha>=s_angle) && (90-Alpha<=e_angle)) pixel(CoordX+X,CoordY-Y,Color);
      if((90+Alpha>=s_angle) && (90+Alpha<=e_angle)) pixel(CoordX+X,CoordY+Y,Color);
      if((180-Alpha>=s_angle) && (180-Alpha<=e_angle)) pixel(CoordX+Y,CoordY+X,Color);
      if((180+Alpha>=s_angle) && (180+Alpha<=e_angle)) pixel(CoordX-Y,CoordY+X,Color);
      if((270-Alpha>=s_angle) && (270-Alpha<=e_angle)) pixel(CoordX-X,CoordY+Y,Color);
      if((270+Alpha>=s_angle) && (270+Alpha<=e_angle)) pixel(CoordX-X,CoordY-Y,Color);
      if((360-Alpha>=s_angle) && (360-Alpha<=e_angle)) pixel(CoordX-Y,CoordY-X,Color);
      Y=Y+1;
    }while(__round((cos(atan(Y/X))*Radius)) < X);
    X=X-1;
  }while((X<=0) || (X<Y));
}

void FillArc (WORD x_center, WORD y_center, WORD radius, WORD s_angle, WORD e_angle, BYTE CurrentColor)
//{ An algorithm to draw an arc. Crude but it works (anyone have a better one?) }
{
  int p;
  int x,y;
  float Alpha;

  if(radius==0)
  {
    pixel(x_center,y_center,CurrentColor); return;
  }
  s_angle = s_angle%361;
  e_angle = e_angle&361;
  if(s_angle>e_angle)
  {
    s_angle=s_angle^e_angle; e_angle=e_angle^s_angle; s_angle=e_angle^s_angle;
  }
  Line(x_center,y_center,x_center-(radius*sin((Pi/180)*s_angle)),
  y_center+(radius*cos((Pi/180)*s_angle)),CurrentColor);
  Line(x_center,y_center,x_center-(radius*sin((Pi/180)*e_angle)),
  y_center+(radius*cos((Pi/180)*e_angle)),CurrentColor);

  x=0;
  y=radius;
  p=3-2*radius;
  while(x<=y)
  {
    Alpha=(RadToDeg*atan(x/y));
    if((Alpha>=s_angle) && (Alpha<=e_angle)) pixel(x_center-x, y_center+y, CurrentColor);
    if((90-Alpha>=s_angle) && (90-Alpha<=e_angle)) pixel(x_center-y, y_center+x, CurrentColor);
    if((90+Alpha>=s_angle) && (90+Alpha<=e_angle)) pixel(x_center-y, y_center-x, CurrentColor);
    if((180-Alpha>=s_angle) && (180-Alpha<=e_angle)) pixel(x_center-x, y_center-y, CurrentColor);
    if((180+Alpha>=s_angle) && (180+Alpha<=e_angle)) pixel(x_center+x, y_center-y, CurrentColor);
    if((270-Alpha>=s_angle) && (270-Alpha<=e_angle)) pixel(x_center+y, y_center-x, CurrentColor);
    if((270+Alpha>=s_angle) && (270+Alpha<=e_angle)) pixel(x_center+y, y_center+x, CurrentColor);
    if((360-Alpha>=s_angle) && (360-Alpha<=e_angle)) pixel(x_center+x, y_center+y, CurrentColor);
    if(p<0)
    {
      p=p+4*x+6;
    }
    else
    {
      p=p+4*(x-y)+10;
       y--;
    }
    x++;
  }
}
void scanleft(WORD x, WORD y)
{
  BYTE v;

  if(x>0)
  {
    do
    {
      x=x-1;
      v=getp12H(x, y);
    }while((!((v==oldvalue) && (v!=fillvalue))) || (x==0));
  }
  x++;
}

void  scanright(WORD x, WORD y)
{
  BYTE v;

  if(x < 639)
  {
    do
    {
      x=x+1;
      v=Getp12H(x, y);
    }while( (!((v==oldvalue) && (v!=fillvalue))) || (x==639));
  }
  x--;
}

WORD  lineadjfill(WORD seedx, WORD seedy, int d, WORD prevxl, WORD prevxr,BYTE Coul)
{
  WORD x,y,xl,xr;
  long int v;

  y=seedy;
  xl=seedx;
  xr=seedx;
  scanleft(xl, y);
  scanright(xr, y);
  Hline(xl, y, xr-xl+1,Coul);
  x=xl;
  while (x<=xr)
  {
    v=Getp12H(x, y+d);
    if((v==oldvalue) && (v!=fillvalue)) x=lineadjfill(x, y+d, d, xl, xr,Coul);
    x++;
  }
  x=xl;
  while(x<=prevxl-1)
  {
    v=Getp12H(x, y-d);
    if((v==oldvalue) && (v!=fillvalue)) x=lineadjfill(x, y-d, -d, xl, xr,Coul);
    x++;
  }
  return(xr);
}

void fillarea(WORD x,WORD y, BYTE coul)
{

  const signed char Up=-1,Down=1;
  WORD xl,xr;

  oldvalue=Getp12H(x, y);
  fillvalue=coul;
  // Vline12H(line, 1024, fillvalue);
  xl = x;
  xr = x;
  scanleft(xl, y);
  scanleft(xr, y);
  lineadjfill(x, y, Up, xl, xr,coul);
  lineadjfill(x, y, Down, xl, xr,coul);
}
