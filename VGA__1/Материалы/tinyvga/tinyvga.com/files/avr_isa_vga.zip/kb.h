// Keyboard communication routines

#ifndef __KB_INCLUDED
#define __KB_INCLUDED
#include "types.h"

#define ISC00 0
#define ISC01 1

// Keyboard konnections
#define PIN_KB	PINB
#define DATAPIN 0

extern BYTE SW_state;

BYTE GetSwitchState();

void init_kb(void);

#pragma vector=INT4_vect 
__interrupt void INT4_interrupt(void);

void decode(unsigned char sc);

void put_kbbuff(unsigned char c);

int GetCharKb(void);

#endif

