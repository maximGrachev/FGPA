#ifndef CLEAR_H
#define CLEAR_H

void TextClear(BYTE attrib);

void Clear04H();

void Clear06H();

void Clear0DH(BYTE color);

void Clear13H(BYTE Color);

void PlanarClear(BYTE Color);

void UnchainedClear(BYTE Color);

#endif
