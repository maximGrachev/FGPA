#ifndef RECEPT_H
#define RECEPT_H

void  ShowProg(void);

#endif
