
#include "defs.h"
#include "config.h"  
#include "types.h"
#include "debug.h"
#include "vgaasm.h"
#include "vga.h"

extern  void  EnableSubSys();
//*********************************************************************

void  sub_474(void)
{
  BYTE  ah=0x10,al;
    
  al = VgaIoReadIx(0x3D4,0x1A)&0xEF;  // al 0x3D4.0x1A
  ah |= al;
  VgaIoWriteIx(0x3D4,(ah<<8)+0x1A);   // 0x3D4.0x1A = ah   

}

//*********************************************************************

void  sub_A28(void)
{
  BYTE  al,ah;
  WORD  temp;
  
  sub_474();
  VgaIoWriteIx(0x3CE,0x000F);         // 0x3CE.0x0F = 0x00 
  // call    sub_465   select 3BxH 3DxH base address
  VgaIoWriteIx(0x3D4,0x001E);         // 0x3D4.0x1E = 0x00
  al = VgaIoReadIx(0x3D4,0x1F);
  temp  = VgaMemoryRead(0xC00472);
  temp += VgaMemoryRead(0xC00473)<<8;
  if(temp == 0x1234)
  {
    if(al&0x08) goto loc_A58;
  }
  VgaIoWriteIx(0x3D4,0x001F);         // 0x3D4.0x1F = 0x00
  VgaIoWriteIx(0x3D4,0x0019);         // 0x3D4.0x19 = 0x00
  VgaIoWriteIx(0x3D4,0x101A);         // 0x3D4.0x1A = 0x10
  // call    sub_465   select 3BxH 3DxH base address
  ah = 0;
  al = VgaIoReadIx(0x3D4,0x1D);
  al = al & 0x04;
  al = al<<1;  
  al = al<<1;
  ah |= al;   
  al = al<<1;
  ah |= al;
  al = VgaIoReadIx(0x3D4,0x1F)&0xF8;
  al |= ah;
  VgaIoWriteIx(0x3D4,(al<<8)+0x1F);                   
loc_A58:
  VgaIoWriteIx(0x3D6,0x0000);
  sub_474();                   
  VgaIoWriteIx(0x3CE,0x000F);
  VgaPortOut(0x3C7,0x0F);
  VgaPortOut(0x3C7,0x0F);
  VgaPortOut(0x3C7,0x0F);
  VgaPortOut(0x3C7,0x0F);           
}

//*********************************************************************

void  sub_1903(void)
{
  BYTE  ah,bh,bl=0xFF;
     
  // 0x3B4  operate ignored
  VgaPortOut(0x3C2,0xA6);
  do
  {    
    bh = bl;
    bh &= 0x0F;
    VgaIoWriteIx(0x3D4,(bl<<8)+0x0E);
    VgaIoWriteIx(0x3D4,(bl<<8)+0x0F);
    ah = VgaIoReadIx(0x3D4,0x0E);
    if((ah&0x0F) != bh) goto locret_1902;
    ah = VgaIoReadIx(0x3D4,0x0F);  
    if((ah&0x0F) != bh) goto locret_1902;
    bl -= 0x55;
  }while(bl != 0xAB);
locret_1902:
  VgaPortOut(0x3C2,0x23);
}

void sub_25A(void)
{
  WORD  i=0x400;
  
  VgaPortOut(0x3D4,0x1A);
  do
  {
    VgaPortIn(0x3D5);
    i--;        
  }while(i);      
}
//*********************************************************************

void  RTGInitNew(void)
// EnableSubSys() already executed
{
  BYTE  al;
  
  // call    sub_465   select 3BxH 3DxH base address
  sub_474();
  VgaIoWriteIx(0x3D4,((VgaIoReadIx(0x3D4,0x1C)&0xFC)<<8)+0x1C);    
  sub_A28();
  // call    sub_1954  ram manipulate
  sub_1903();
  // INT10H sub_162
    VgaIoWriteIx(0x3C4,0x0100);
    sub_474();
    VgaIoWriteIx(0x3D4,((VgaIoReadIx(0x3D4,0x19)&0x0C)<<8)+0x19);
    VgaIoWriteIx(0x3CE,((VgaIoReadIx(0x3CE,0x0C)&0xCF)<<8)+0x0C);
    VgaIoReadIx(0x3CE,0x0B);
    VgaIoWriteIx(0x3CE,0x3A0B);
    al = 0x7B;
    if(VgaIoReadIx(0x3D4,0x1D)&0x20) 
    {
      if(!(VgaIoReadIx(0x3D4,0x1E)&0x03))
      {   
        sub_474();      
        VgaIoWriteIx(0x3CE,((VgaIoReadIx(0x3CE,0x0B)&0xFB)<<8)+0x0B);
        VgaIoWriteIx(0x3CE,((VgaIoReadIx(0x3CE,0x0C)&0xBF)<<8)+0x0C);
        VgaIoWriteIx(0x3CE,((VgaIoReadIx(0x3CE,0x0B)|0x80)<<8)+0x0B);
        al = 0x24;
      }
    }
    // loc_248 entry
    VgaIoReadIx(0x3CE,0x15);
    VgaIoWriteIx(0x3CE,(al<<8)+0x15);
    sub_25A();
    // sub_130
      VgaIoWriteIx(0x3D6,0x0000);
      sub_474();
      VgaIoWriteIx(0x3CE,0x000F);
      VgaPortOut(0x3C7,0x0F);
      VgaPortOut(0x3C7,0x0F);
      VgaPortOut(0x3C7,0x0F);
      VgaPortOut(0x3C7,0x0F);                       
                 
  VgaIoWriteIx(0x3CE,0x3A0B);
  VgaIoWriteIx(0x3CE,0x7B15); 
//  VgaIoWriteIx(0x3CE,0x0D0e);  
//  VgaIoWriteIx(0x3CE,0x0109);  
//  VgaIoWriteIx(0x3CE,0x060A);
//  VgaIoWriteIx(0x3CE,0xCF0D);
           
}
//*********************************************************************
