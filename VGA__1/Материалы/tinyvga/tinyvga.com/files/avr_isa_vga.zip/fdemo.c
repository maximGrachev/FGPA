
#include <pgmspace.h>
#include <stdio.h>
#include "types.h"

extern void   getch(void);

//*********************************************************************
void Fdemo(void)
{


  printf_P("Copyrighted FAT source not available\n");
  printf_P("Press ESC !");
	
}
//*********************************************************************
