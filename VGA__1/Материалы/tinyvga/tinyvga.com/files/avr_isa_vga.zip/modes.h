#ifndef MODES_H
#define MODES_H
#include "types.h" 


void SetVideoMode(BYTE mode);


#endif
