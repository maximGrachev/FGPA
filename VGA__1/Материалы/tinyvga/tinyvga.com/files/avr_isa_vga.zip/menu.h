#ifndef MENU_H
#define MENU_H

//BYTE SelectMenu(MENU_PROP_ST __generic *menupr,BYTE HighLight);

//void  DrawMenu(MENU_PROP_ST __generic *menupr);

BYTE  ExeMenu(BYTE ix);

#endif
