#ifndef VGA_H
#define VGA_H

// Prototypes

void  VgaMemoryWriteOld(register DBLWORD addr,register BYTE val);

BYTE  VgaMemoryReadOld(register DBLWORD addr);

void  IoPortOutB(register WORD add,register BYTE val);

void  IoPortOutW(register WORD add,register WORD val);

BYTE  IoPortInB(WORD add);

WORD  IoPortInW(WORD add);

void  RTGInit(void);

void  TVGAInit(void);

CHIP_TYPE_EN  VgaInit();
#endif

