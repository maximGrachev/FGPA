#ifndef TXTRTNE_H
#define TXTRTNE_H

extern WORD   CursorScreen;
extern BYTE   CurrentAttrib;

void  NextScrPage();

void  PrevScrPage();

void  SetScrPage(BYTE page);

void  CursorOn(void);

void  CursorOff(void);

void  SetHwCursor(WORD pos);

void TextLineScrllUp(void);

void Gotoxy(BYTE x, BYTE y);

void SetForeColor(BYTE col);

void SetBackColor(BYTE col);

void SetColor(BYTE att);

#endif
