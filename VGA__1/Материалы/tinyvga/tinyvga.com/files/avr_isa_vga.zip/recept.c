#include <stdio.h>
#include <pgmspace.h>
#include <ina90.h>
#include <string.h>
#include "defs.h"
#include "config.h"
#include "types.h"
#include "txtrtne.h"
#include "debug.h"

extern  BYTE   CursorCol;
extern __flash BOX_CHARS BxChArr[4];


DYEING_PROG_ST  DyeingProg =
{
 "000000/-99",
 "Csavazott 21333               "
};
void TextBox2(DYEING_PROG_ST *Dy)
{


  register BYTE  i,x,y,wlim,hlim;

  x = 1;
  y = 1;
  wlim = 80;
  hlim = 20;

  CursorOn();
  SetColor(0x0E);
  Gotoxy(x,y);
  putchar(BxChArr[1].TopLeftChar);
  putchar(0x5B);
  for(i=0;i<10;i++) putchar(Dy->ProgNmbr[i]);
  putchar(0x5D);
  for(i=0;i<5;i++) putchar(BxChArr[1].HorizontalChar);
  putchar(0x5B);
  for(i=0;i<30;i++) putchar(Dy->ProgName[i]);
  putchar(0x5D);
  while(CursorCol!=80) putchar(BxChArr[1].HorizontalChar);
  putchar(BxChArr[1].TopRightChar);
  for(i=0;i<hlim;i++)
  {
    Gotoxy(x,y+i+1);
    putchar(BxChArr[1].VerticalChar);
    Gotoxy(wlim,y+i+1);
    putchar(BxChArr[1].VerticalChar);
  }
  Gotoxy(x,y+hlim);
  putchar(BxChArr[1].BotLeftChar);
  for(i=0;i<wlim-2;i++) putchar(BxChArr[1].HorizontalChar);
  putchar(BxChArr[1].BotRightChar);
  // Only testing
  printf_P("\r\n");
  putchar(0x01);
  putchar(0x02);
  SetColor(0xE0);
  printf_P("\x90\xDB");
  printf_P("\x86\x87");
  printf_P("\xC9\xCA");
}

void  ShowProg(void)
{
  TextBox2(&DyeingProg);
}


