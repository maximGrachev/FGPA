#ifndef PALETTE_H
#define PALETTE_H


// Prototypes

void setpal(BYTE color, BYTE r, BYTE g, BYTE b);

void setpalette4();

void setpalette16();

void setpalette256();
void setpal(BYTE color, BYTE r, BYTE g, BYTE b);
#endif
