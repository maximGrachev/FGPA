#ifndef TESTS_H
#define TESTS_H

void ModeTest(void);

void TextTest(void);

void  TauronTests(void);

#endif
