#ifndef FONT_H
#define FONT_H

// Externs

extern __flash unsigned char Font8x16[];
extern __flash unsigned char Font8x8[];

// Prototypes

void SetFont8x16(void);

void SetFont8x8(void);

void  FontsRead( BYTE __flash *biosfont,BYTE bytesperchar );

#endif
