#ifndef DEBUG_H
#define DEBUG_H
#include "types.h" 

void  DumpIndexed(WORD baseIx);

void  DumpBase(void);

void  DumpIoRegs(void);

void SendReadBack(WORD Base,WORD IxBase,BYTE Ix,BYTE Command);

BYTE  Remote(void);

#endif
