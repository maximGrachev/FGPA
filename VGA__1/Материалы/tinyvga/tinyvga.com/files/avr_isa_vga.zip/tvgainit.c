#include "vgaregs.h"
#include "config.h"  
#include "types.h"
#include "debug.h"
#include "vgaasm.h"
#include "vga.h"

//*********************************************************************

void TridentNew()
{
   VgaPortOut(SEQ_ADDR,0x0B);
   VgaPortIn(SEQ_ADDR+1);
}

//*********************************************************************

void TridentOld()
{
   VgaPortOut(SEQ_ADDR,0x0B);
   VgaPortOut(SEQ_ADDR+1,0x00);
}

//*********************************************************************
void  TVGAInit(void)
{
   BYTE  al,bh;
   WORD  i=0; 
  
   TridentOld();
   VgaPortOut(0x3C4,0x0D);      // select register 0D
   al = VgaPortIn(0x3C5);       // Read the register
   if ( ((al & 0x0E)==0x0C) && ((VgaPortIn(0x3CC)&0x67)==0x67) )
      goto JZ0E88;
   VgaPortOut(0x3C8,0x00);   
   do      
   {  
      VgaPortOut(0x3C9,0x00);
      i++;
   }while(i<768);   
   VgaPortOut(0x3C2,0x23);
   TridentNew();

   VgaPortOut(0x3C4,0x0E);   
   al = VgaPortIn(0x3C5);
   VgaPortOut(0x3C5,(al|0x80)^0x02);
   VgaPortOut(0x3C4,0x0C);
   al = VgaPortIn(0x3C5);
   bh = (al|0x80)&0xFE;
   VgaPortOut(0x3C4,0x07);
   VgaPortOut(0x3C5,0x24);
   VgaPortOut(0x3C2,0x01);
   VgaPortOut(0x3D4,0x28);   
   if ((al = VgaPortIn(0x3D5))==0x0C)
   {
      VgaPortOut(0x3D5,al|0x04);
   }
   VgaPortOut(0x3C4,0x0F);
   VgaPortOut(0x3C5,VgaPortIn(0x3C5)&0x7F);
   VgaPortOut(0x3C4,0x0C);
   VgaPortOut(0x3C5,bh);      //  bh
   VgaPortOut(0x3C4,0x0E);
   VgaPortOut(0x3C5,(VgaPortIn(0x3C5)&0x7F)^0x02);
   VgaPortOut(0x3C4,0x0F);
   if(VgaPortIn(0x3C5) != 0x08)
   {
//   call 0179
   }
   TridentOld();
   VgaPortOut(0x3C4,0x0D);   
   VgaPortOut(0x3C5,0x20);
   VgaPortOut(0x3C4,0x0E);   
   VgaPortOut(0x3C5,0xA0);
   TridentNew();
   VgaPortOut(0x3C4,0x0E);   
   VgaPortOut(0x3C5,0x02);  //oooo  02
   VgaPortOut(0x3CE,0x06);   
   if ( (al = VgaPortIn(0x3CF))==0x0C)
   {
      VgaPortOut(0x3CF,(al&0xF3)|0x04);
   }
   VgaPortOut(0x3C4,0x0D);   
   VgaPortOut(0x3C5,0x00);
   VgaPortOut(0x3D4,0x1E);
   al = VgaPortIn(0x3D5);
JZ0E88:
   VgaPortOut(0x3D5,(al^al));

   VgaPortOut(0x3D4,0x1F);   
   VgaPortOut(0x3D5,0x81);

   VgaPortOut(0x3D4,0x25);   
   VgaPortOut(0x3D5,0xFF);


//   VgaPortOut(0x3C4,0x0D);     // select register 0D
//   al = VgaPortIn(0x3C5);    // Read the register
//   if ( ((al & 0x0E)==0x0C) && ((VgaPortIn(0x3CC)&0x67)==0x67) )
//      goto J0EDE;

//   VgaPortOut(0x3D4,0x30);
//   VgaPortOut(0x3D4,0x01);   

    VgaPortOut(0x3C6,0xFF);     
    VgaPortOut(0x3C6,0xFF);     
    VgaPortOut(0x3C6,0xFF);         
}
//*********************************************************************
