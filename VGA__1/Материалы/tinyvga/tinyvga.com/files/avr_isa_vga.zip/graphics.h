#ifndef GRAPHICS_H
#define GRAPHICS_H

void pixel(WORD x, WORD y, BYTE color);

void drawline(int x1, int y1, int x2, int y2, BYTE col);

void drawrect(int x1, int y1, int x2, int y2, BYTE color);

void hline(int x1, int x2, int y, BYTE color);

void vline(int y1, int y2, int x, BYTE color);

void fillrect(int x1, int y1, int x2, int y2, BYTE color);

void drawellipse(int cx, int cy, int rx, int ry, BYTE color );

void drawellipsefilled(int cx, int cy, int rx, int ry, BYTE color );

void  DrawCircle(WORD x, WORD y, WORD rad,BYTE col);

void  PutChar12h(BYTE x, WORD y, char cha, BYTE FColor, BYTE BColor);

void  PutString12h(BYTE x, WORD y,char __farflash *str, BYTE FColor, BYTE BColor);

#endif
